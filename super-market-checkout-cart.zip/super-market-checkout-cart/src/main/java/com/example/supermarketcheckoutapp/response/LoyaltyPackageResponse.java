package com.example.supermarketcheckoutapp.response;

public class LoyaltyPackageResponse<T> extends LoyaltyResponse{
    private String message;
    private T data;
}
