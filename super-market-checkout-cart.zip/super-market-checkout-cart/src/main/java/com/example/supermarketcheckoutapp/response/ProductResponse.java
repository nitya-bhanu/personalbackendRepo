package com.example.supermarketcheckoutapp.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductResponse {
    private String response;
}
