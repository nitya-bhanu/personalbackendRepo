package com.example.supermarketcheckoutapp.request;

public class ProdReqUser {
    private String title;
    private Integer quantity;
    private String category;
    private String description;
}
