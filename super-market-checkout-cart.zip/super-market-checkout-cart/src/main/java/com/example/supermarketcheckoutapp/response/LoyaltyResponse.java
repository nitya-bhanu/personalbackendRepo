package com.example.supermarketcheckoutapp.response;

public class LoyaltyResponse {
    private String response;
}
